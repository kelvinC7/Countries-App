package com.example.countries

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
