
class Images {
  static const String logo = 'assets/logos/app_logo.png';
  static const String placeholder = 'assets/images/placeholder.jpg';
}