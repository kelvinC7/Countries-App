

import 'package:flutter/material.dart';

class ColorResources {

  static const Color primaryColor = Colors.deepPurple;
  

  static getSecondaryColor() {
    return Colors.deepPurpleAccent;
  }
  // Add color resources here in the future
} 