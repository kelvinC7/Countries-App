

class AppConstants {
  static const String appName = "Countries";

  static const String baseUrl = "https://restcountries.com/v3.1/";
  
}