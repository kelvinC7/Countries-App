

import 'package:countries/utils/app_constants.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class ApiClient extends GetxService {

String get appBaseUrl {

    return AppConstants.baseUrl;
  }


Future<Response> getData(String uri) async {


    var url = Uri.parse(appBaseUrl + uri);

    try {
      Response response = await http.get(url).then((http.Response res) {
        return Response(
            statusCode: res.statusCode,
            body: res.body,
            statusText: res.reasonPhrase);
      });


      return response;
    } catch (e) {
      return Response(statusCode: 1, statusText: e.toString());
    }
  }
}