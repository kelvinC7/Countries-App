class RouteHelper {
  static const String splash = '/splash';
  static const String home = '/home';
  static const String details = '/details';
  static const String favorites = '/favorites';

  static getSplashRoute() => splash;
  static getHomeRoute() => home;
  static getDetailsRoute() => details;
  static getFavoritesRoute() => favorites;
}
