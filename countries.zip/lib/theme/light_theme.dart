

import 'package:countries/utils/color_resources.dart';
import 'package:flutter/material.dart';

ThemeData lightTheme = ThemeData(
  colorScheme: ColorScheme.fromSeed(seedColor: ColorResources.primaryColor),
  useMaterial3: true,
);